# %%
import warnings
warnings.filterwarnings('ignore')  # Ignore warnings

import torch_pruning as tp
import time
from torch.quantization import QuantStub, DeQuantStub

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
import os
import numpy as np
import cv2
from ptflops import get_model_complexity_info


# %%
class EmotionRecognitionModel(nn.Module):
    def __init__(self, num_classes=5):
        super(EmotionRecognitionModel, self).__init__()
        self.quant = QuantStub()
        self.dequant = DeQuantStub()

        self.conv1 = nn.Conv2d(3, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.conv3 = nn.Conv2d(64, 128, kernel_size=3, padding=1)
        self.conv4 = nn.Conv2d(128, 128, kernel_size=1, padding=0)
        self.pool = nn.MaxPool2d(2, 2)
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(128 * 6 * 6, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, num_classes)
        self.dropout = nn.Dropout(0.5)

    def forward(self, x):
        x = self.quant(x)
        x = F.relu(self.conv1(x))
        x = self.pool(x)
        x = F.relu(self.conv2(x))
        x = self.pool(x)
        x = F.relu(self.conv3(x))
        x = self.dropout(x)
        x = self.pool(x)
        x = F.relu(self.conv4(x))
        x = self.dropout(x)
        x = self.flatten(x)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = F.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.fc3(x)
        x = self.dequant(x)
        return x


# %%
model = EmotionRecognitionModel()
model.load_state_dict(torch.load('MyModelFaceRecogD3.pth', map_location=torch.device('cuda')))
# %%
val_path = 'validation/'
print(os.listdir(val_path))
# Loading validation data
x_val = []
y_val = []
for class_idx, class_name in enumerate(['happy', 'sad', 'fear', 'surprise', 'neutral']):
    class_folder = os.path.join(val_path, class_name)
    for img_file in os.listdir(class_folder):
        img = cv2.imread(os.path.join(class_folder, img_file))
        img = cv2.resize(img, (48, 48))
        x_val.append(img)
        y_val.append(class_idx)

x_val = np.array(x_val)
y_val = np.array(y_val)

y_val_tensor = torch.tensor(y_val, dtype=torch.long)
x_val_tensor = torch.tensor(x_val, dtype=torch.float32).permute(0, 3, 1, 2) / 255.0

val_dataset = TensorDataset(x_val_tensor, y_val_tensor)
val_loader = DataLoader(val_dataset, batch_size=100, shuffle=False)
# %%

example_inputs = torch.randn(1, 3, 48, 48)

# %%
# pruning 적용 함수
import torch.nn.utils.prune as prune

conv_prune = 0.5
fc_prune = 0.5
model = EmotionRecognitionModel()
model.load_state_dict(torch.load('MyModelFaceRecogD3.pth', map_location=torch.device('cuda')))


def apply_pruning(model, conv_prune=conv_prune, fc_prune=fc_prune):
    for name, module in model.named_modules():
        if isinstance(module, nn.Conv2d):
            prune.ln_structured(module, name='weight', amount=conv_prune, n=2, dim=0)  # 필터의 20%를 pruning
        elif isinstance(module, nn.Linear):
            prune.ln_structured(module, name='weight', amount=fc_prune, n=2, dim=0)  # FC 레이어의 뉴런 40%를 pruning


# pruning 완료 후 가중치에서 마스크 제거
def finalize_pruning(model):
    for name, module in model.named_modules():
        if isinstance(module, (nn.Conv2d, nn.Linear)):
            prune.remove(module, 'weight')


apply_pruning(model)
finalize_pruning(model)


# 가중치 값이 0인 인덱스 찾는 함수
def find_zero_weight_indices(model):
    zero_indices = {}
    for name, module in model.named_modules():
        if isinstance(module, nn.Conv2d):
            weight = module.weight.data
            # 출력 채널별로 가중치의 절대값 합 계산
            weight_abs_sum = weight.abs().view(weight.shape[0], -1).sum(dim=1)
            # 합이 0인 경우 (완전히 pruning된 필터)
            zero_channels = (weight_abs_sum == 0).nonzero(as_tuple=False).squeeze().tolist()
            zero_indices[name] = zero_channels
        elif isinstance(module, nn.Linear):
            weight = module.weight.data
            # 각 뉴런의 입력 가중치 절대값 합 계산
            weight_abs_sum = weight.abs().sum(dim=1)
            # 합이 0인 경우 (완전히 pruning된 뉴런)
            zero_neurons = (weight_abs_sum == 0).nonzero(as_tuple=False).squeeze().tolist()
            zero_indices[name] = zero_neurons
    return zero_indices


zero_weight_indices = find_zero_weight_indices(model)
# %%
import copy

model = EmotionRecognitionModel()
model.load_state_dict(torch.load('MyModelFaceRecogD3.pth', map_location=torch.device('cuda')))
net = copy.deepcopy(model)
net.to('cuda')
example_inputs = torch.randn(1,3, 48, 48)
example_inputs.to('cuda')

DG = tp.DependencyGraph().build_dependency(net.to('cuda'), example_inputs=example_inputs.to('cuda'))

pruning_idxs = zero_weight_indices['conv1']
pruning_group = DG.get_pruning_group(net.conv1, tp.prune_conv_out_channels, idxs=pruning_idxs)

if DG.check_pruning_group(pruning_group):
    pruning_group.prune()

pruning_idxs = zero_weight_indices['conv2']
pruning_group = DG.get_pruning_group(net.conv2, tp.prune_conv_out_channels, idxs=pruning_idxs)

if DG.check_pruning_group(pruning_group):
    pruning_group.prune()

pruning_idxs = zero_weight_indices['conv3']
pruning_group = DG.get_pruning_group(net.conv3, tp.prune_conv_out_channels, idxs=pruning_idxs)

if DG.check_pruning_group(pruning_group):
    pruning_group.prune()

pruning_idxs = zero_weight_indices['conv4']
pruning_group = DG.get_pruning_group(net.conv4, tp.prune_conv_out_channels, idxs=pruning_idxs)

if DG.check_pruning_group(pruning_group):
    pruning_group.prune()

pruning_idxs = zero_weight_indices['fc1']
pruning_group = DG.get_pruning_group(net.fc1, tp.prune_linear_out_channels, idxs=pruning_idxs)

pruning_idxs = zero_weight_indices['fc2']
pruning_group = DG.get_pruning_group(net.fc2, tp.prune_linear_out_channels, idxs=pruning_idxs)

if DG.check_pruning_group(pruning_group):
    pruning_group.prune()

# 3. prune all grouped layer that is coupled with model.conv1
if DG.check_pruning_group(pruning_group):
    pruning_group.prune()

base_macs, base_nparams = tp.utils.count_ops_and_params(model.to('cuda'), example_inputs.to('cuda'))
print('======================')
print('Before')
print(f'\tMACs: {base_macs / 1e6} M')
print(f'\tParams: {base_nparams / 1e6} M')
prune_macs, prune_nparams = tp.utils.count_ops_and_params(net.to('cuda'), example_inputs.to('cuda'))
print('After')
print(f'\tMACs: {prune_macs / 1e6} M')
print(f'\tParams: {prune_nparams / 1e6} M')
print('======================')


# %%
def print_model_size(mdl):
    torch.save(mdl.state_dict(), "tmp.pt")
    print("%.2f MB" % (os.path.getsize("tmp.pt") / 1e6))
    os.remove('tmp.pt')


# %%
correct_val = 0
total_val = 0

start_time = time.time()

net.eval()

with torch.no_grad():
    for inputs, labels in val_loader:
        outputs = net(inputs.to('cuda'))
        _, predicted_val = torch.max(outputs, 1)
        total_val += labels.size(0)
        correct_val += (predicted_val.to('cuda') == labels.to('cuda')).sum().item()

    val_acc = correct_val / total_val  # Validation accuracy for this epoch
    end_time = time.time()
    print(val_acc)

    runtime = end_time - start_time
    print(f'Prediction Runtime: {runtime:.2f} seconds')
    total_params = sum(p.numel() for p in net.parameters())
    print(total_params)
    prune_macs, prune_nparams = tp.utils.count_ops_and_params(net.to('cuda'), example_inputs.to('cuda'))
    print(f'\tMACs: {prune_macs / 1e6} M')
    print(f'\tParams: {prune_nparams / 1e6} M')
    print_model_size(model)
    flops, params = get_model_complexity_info(net, (3,48,48), as_strings=True, print_per_layer_stat=True)
    print("flops : ", flops)

torch.save(net.state_dict(), "net.pth")
'''
======================
Before
	MACs: 26.569221 M
	Params: 2.602181 M
After
	MACs: 7.828997 M
	Params: 1.274213 M
======================
0.3776480400333611
Prediction Runtime: 19.64 seconds
1274213
	MACs: 7.828997 M
	Params: 1.274213 M
10.41 MB
flops :  7.96 MMac
'''


